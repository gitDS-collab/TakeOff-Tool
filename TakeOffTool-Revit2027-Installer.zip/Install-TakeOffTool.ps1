[CmdletBinding()]
param()

$ErrorActionPreference = 'Stop'
$packageRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
$sourceDll = Join-Path $packageRoot 'Plugin\QuantityTakeoffRevit2027.dll'

if (-not (Test-Path -LiteralPath $sourceDll)) {
    throw "Plugin DLL was not found: $sourceDll"
}

$addinRoot = Join-Path $env:APPDATA 'Autodesk\Revit\Addins\2027'
$pluginRoot = Join-Path $addinRoot 'TakeOffTool'
$targetDll = Join-Path $pluginRoot 'QuantityTakeoffRevit2027.dll'
$manifestPath = Join-Path $addinRoot 'TakeOffTool.addin'

New-Item -ItemType Directory -Force -Path $pluginRoot | Out-Null
Copy-Item -LiteralPath $sourceDll -Destination $targetDll -Force

$escapedDll = [Security.SecurityElement]::Escape($targetDll)
$manifest = @"
<?xml version="1.0" encoding="utf-8" standalone="no"?>
<RevitAddIns>
  <AddIn Type="Application">
    <Name>TakeOff Tool</Name>
    <Assembly>$escapedDll</Assembly>
    <AddInId>8FD5CBF5-1859-4CF8-9DEA-0945733D1E7E</AddInId>
    <FullClassName>QuantityTakeoffRevit2027.App</FullClassName>
    <VendorId>QT27</VendorId>
    <VendorDescription>TakeOff Tool: local quantity takeoff, schedules, CSV, and Excel export.</VendorDescription>
  </AddIn>
</RevitAddIns>
"@

Set-Content -LiteralPath $manifestPath -Value $manifest -Encoding utf8
Write-Host "TakeOff Tool installed for Revit 2027. Restart Revit before using the add-in."
