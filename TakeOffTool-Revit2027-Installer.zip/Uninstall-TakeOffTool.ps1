[CmdletBinding()]
param()

$ErrorActionPreference = 'Stop'
$addinRoot = Join-Path $env:APPDATA 'Autodesk\Revit\Addins\2027'
$pluginRoot = Join-Path $addinRoot 'TakeOffTool'
$manifestPath = Join-Path $addinRoot 'TakeOffTool.addin'

if (Test-Path -LiteralPath $manifestPath) {
    Remove-Item -LiteralPath $manifestPath -Force
}

if (Test-Path -LiteralPath $pluginRoot) {
    Remove-Item -LiteralPath $pluginRoot -Recurse -Force
}

Write-Host "TakeOff Tool was removed from Revit 2027."
